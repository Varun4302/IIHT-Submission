package assignment02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class deleteCustomer {
	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static final String query = "delete from customer where id = ?";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(query)){
			System.out.println("Enter Customer id to be deleted");
			Scanner sc = new Scanner(System.in);
			int id = sc.nextInt();
			ps.setInt(1, id);
			System.out.println(ps.executeUpdate());			
		}
		catch(SQLException e) {
			
		}
		
		
		
		
	}

}
