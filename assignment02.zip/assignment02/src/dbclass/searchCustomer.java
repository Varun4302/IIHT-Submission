package assignment02;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class searchCustomer {

	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static final String query= "select * from customer";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		// TODO Auto-generated method stub
		
		try(Connection con = DriverManager.getConnection(dburl,user,pass);
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(query))
		{
	
			System.out.println("ID Name Age Address Salary");
			while(rs.next()) {
				System.out.println(rs.getInt("id"));
				System.out.print(rs.getString("name"));
				System.out.print(rs.getInt("age"));
				System.out.print(rs.getString("address"));
				System.out.print(rs.getString("salary"));
				
			}
		
	}catch(SQLException e) {
	System.out.println(e);	
	}
	

	}

}
