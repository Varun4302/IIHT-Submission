package assignment02;

import java.sql.*;

public class jdbcclass {

	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static final String query= "Select * from cstable";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		try(Connection con = DriverManager.getConnection(dburl,user,pass);
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(query)){
			while(rs.next()) {
				System.out.print(""+rs.getInt("csID"));
				System.out.println(""+rs.getString("csName"));
			}
			
			
			
		}
		catch(SQLException e) {
			
			System.out.println(e);
		}
		
		
	}

}
